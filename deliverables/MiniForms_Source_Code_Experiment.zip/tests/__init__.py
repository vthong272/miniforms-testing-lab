"""MiniForms research test suites."""
